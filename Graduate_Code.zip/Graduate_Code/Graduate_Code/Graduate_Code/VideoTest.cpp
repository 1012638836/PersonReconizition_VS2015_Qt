#include"VideoTest.h"
#include"ShowTestedPicture.h"
VideoTest::VideoTest(QWidget *parent) :QDialog(parent), ui(new Ui::VideoTest)
{
	ui->setupUi(this);
	connect(ui->OpenVideopushButton, SIGNAL(clicked()), this, SLOT(ClickedTestVideo()));
	connect(ui->OpenSVMpushButton, SIGNAL(clicked()), this, SLOT(OpenSVMFile()));
	connect(ui->StartTestpushButton, SIGNAL(clicked()), this, SLOT(StartTest()));
	connect(&theTimer, SIGNAL(timeout()), this, SLOT(onTimeout()));
}
void VideoTest::OpenSVMFile()
{
	SVMPath = QFileDialog::getOpenFileName(this, QString::fromLocal8Bit("Open SVM model"), ".", QString::fromLocal8Bit("SVM model(*.yml *.xml)"));
	if (SVMPath.length() <= 0) { return; }
	hog.load(SVMPath.toStdString());
}
VideoTest::~VideoTest()
{
	delete ui;
}
void VideoTest::RecieveToBoard()
{
	this->show();
}
void VideoTest::ClickedTestVideo()
{
	VideoFileName = QFileDialog::getOpenFileName(this, QString::fromLocal8Bit("Open video file"), ".", QString::fromLocal8Bit("Video File(*.avi *.mp4)"));
	cap.open(VideoFileName.toStdString());
	if (!cap.isOpened())
	{
		QMessageBox::warning(NULL, "��ʾ", QString::fromLocal8Bit("��Ƶ�ļ���ʧ�ܣ�"), QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
	}
	//--���ÿ�ʼ֡
	long frameToStart = 0;
	cap.set(CV_CAP_PROP_POS_FRAMES, frameToStart);
	//--��ȡ֡��
	double rate = cap.get(CV_CAP_PROP_FPS);
	double delay = 1000 / rate;
	theTimer.start(delay);
}
void VideoTest::onTimeout()
{
	Mat frame;
	//--��ȡ��һ֡
	if (!cap.read(frame)) { return; }
	QImage image = (cvMat2QImage(frame));
	ui->OriginalVideolabel->setScaledContents(true);
	QSize qs = ui->OriginalVideolabel->rect().size();
	ui->OriginalVideolabel->setPixmap(QPixmap::fromImage(image).scaled(qs));
	ui->OriginalVideolabel->repaint();
}
void VideoTest::StartTest()
{
	cap.open(VideoFileName.toStdString());
	for (size_t i = 0;; i++)
	{
		Mat img;
		if (cap.isOpened())
		{
			cap >> img;
		}
		if (img.empty()) { return; }
		vector<Rect> detections;
		vector<double> foundWeights;
        
		hog.detectMultiScale(img, detections, foundWeights);
		for (size_t j = 0; j < detections.size(); j++)
		{
			if (foundWeights[j] < 0.5) { continue; }
			Scalar color = Scalar(0, foundWeights[j] * foundWeights[j] * 200, 0);
			rectangle(img, detections[j], color, img.cols / 400 + 1);
		}

		QImage image = cvMat2QImage(img);
		ui->TestedVideolabel->setScaledContents(true);
		QSize qs = ui->TestedVideolabel->rect().size();
		ui->TestedVideolabel->setPixmap(QPixmap::fromImage(image).scaled(qs));
		ui->TestedVideolabel->repaint();
	}
}