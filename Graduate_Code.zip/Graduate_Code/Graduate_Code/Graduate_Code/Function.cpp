#include "Function.h"

CHog::CHog(TrainProcess & a)
{
	pos_filename = a.pos_file_name;
	neg_filename = a.neg_file_name;
}

void CHog::StartTrainProcess()
{
	//--�������
	int detector_width = 64;
	int detector_height = 128;
	Size detector_size = Size(detector_width, detector_height);
	ui->textBrowser->setText(QString::fromLocal8Bit("Positive images are being loaded..."));

}
