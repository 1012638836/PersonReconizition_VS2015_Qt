#include "ShowTestedPicture.h"

TestedPicture::TestedPicture(QWidget *parent):QDialog(parent), ui(new Ui::TestedPicture)
{
	ui->setupUi(this);

	timer = new QTimer();
	connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(ConvertToPictureTest()));
	connect(timer, SIGNAL(timeout()), this, SLOT(TimeOut()));
	connect(ui->NextpushButton, SIGNAL(clicked()), this, SLOT(ClickedNextPicture()));
	connect(ui->LastpushButton, SIGNAL(clicked()), this, SLOT(ClickedLastPicture()));
	connect(ui->StartTestpushButton, SIGNAL(clicked()), this, SLOT(ClickedStartTest()));
	connect(ui->SVMpushButton, SIGNAL(clicked()), this, SLOT(GetSVMPath()));
}
TestedPicture::~TestedPicture()
{
	delete ui;
	delete timer;
}
void TestedPicture::closeEvent(QCloseEvent * ev)
{
	if (QMessageBox::Yes == QMessageBox::question(this, QString::fromLocal8Bit("��ʾ"), QString::fromLocal8Bit("�Ƿ񷵻�������?"), QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes))
	{
		emit Signal_ToMainWindow();
	}
	else
	{
		ev->ignore();
	}

}
void TestedPicture::ConvertToTestPicture()
{
	this->show();
}
void TestedPicture::TimeOut()
{
	if (pos > test_image.length()) { pos = 0; }
	ui->PicturePathlabel->setText(test_image.substr(pos).c_str());
	pos++;
}
void TestedPicture::ClickedNextPicture()
{
	Picture_Pos++;
	if (Picture_Pos == Picture_Num - 1) { ui->NextpushButton->setEnabled(false); }
	ui->LastpushButton->setEnabled(true);
	ShowOriginalPicture();
}
void TestedPicture::ClickedLastPicture()
{
	Picture_Pos--;
	if (Picture_Pos == 0) { ui->LastpushButton->setEnabled(false); }
	ShowOriginalPicture();
}
void TestedPicture::ShowOriginalPicture()
{
	img_name = QString::fromStdString(files[Picture_Pos]);
	Mat src = imread(img_name.toUtf8().data());
	/*
	cvtColor(src, src, CV_BGR2RGB);
	img = QImage((const unsigned char *)(src.data), src.cols, src.rows, QImage::Format_RGB888);
	*/
	img = cvMat2QImage(src);
	img = img.scaled(ui->Originallabel->width(), ui->Originallabel->height(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
	ui->Originallabel->setPixmap(QPixmap::fromImage(img));
	ui->Originallabel->show();
}
void TestedPicture::ClickedStartTest()
{
	if (!HOGLoadSuccess)
	{
		QMessageBox::warning(NULL, "warning", QString::fromLocal8Bit("HOG����û�м��سɹ��������ļ�Ŀ¼��"), QMessageBox::Yes);
		return;
	}
	String file_name = files[Picture_Pos];
	Mat Test_Picture = imread(file_name);
	QImage TestImage;
	vector<Rect> detections;
	vector<double> foundWeights;

	hog.detectMultiScale(Test_Picture, detections, foundWeights);//kernel function 
	for (size_t j = 0; j < detections.size(); j++)
	{
		if (foundWeights[j] < 0.5) { continue; }
		Scalar color = Scalar(0, foundWeights[j] * foundWeights[j] * 200, 0);
		rectangle(Test_Picture, detections[j], color, Test_Picture.cols / 400 + 1);
	}
	/*
	cvtColor(Test_Picture, Test_Picture, CV_BGR2RGB);
	TestImage = QImage((const unsigned char *)(Test_Picture.data), Test_Picture.cols, Test_Picture.rows, QImage::Format_RGB888);
	*/
	TestImage = cvMat2QImage(Test_Picture);
	TestImage = TestImage.scaled(ui->TestedPicturelabel->width(), ui->TestedPicturelabel->height(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
	
	
	ui->TestedPicturelabel->setPixmap(QPixmap::fromImage(TestImage));
	ui->TestedPicturelabel->show();
}
void TestedPicture::GetSVMPath()
{
	SVMPath = QFileDialog::getOpenFileName(this, QString::fromLocal8Bit("Open SVM model"), ".", QString::fromLocal8Bit("SVM model(*.yml *.xml)"));
	if (SVMPath.length() <= 0) { return; }
	hog.load(SVMPath.toStdString());
	if(SVMPath.length() > 0){HOGLoadSuccess = true;}
}
void TestedPicture::ConvertToPictureTest()
{
	test_image = QFileDialog::getExistingDirectory(NULL, "caption", ".").toStdString();
	timer->start(500);
	pos = 0;
	files.clear();//�������
	glob(test_image, files);
	Picture_Num = files.size();
	if (files.size() == 0)
	{
		QMessageBox::warning(NULL, "warning", QString::fromLocal8Bit("��Ŀ¼�ļ���û�п��Դ򿪵�ͼƬ"), QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
	}
//	img_name = QFileDialog::getOpenFileName(this, QString::fromLocal8Bit("Open Image"), ".", QString::fromLocal8Bit("Image Files(*.png *.jpg *.jpeg *.bmp)"));
	//--������ļ���û����Ӧ��ͼƬ,Ĭ����ʾ���ǵ�һ��ͼƬ
	if (files.size() != 0)
	{
		Picture_Pos = 0;//��һ��ͼƬ������
		ShowOriginalPicture();
		ui->LastpushButton->setEnabled(false);
		if (Picture_Num == 1) { ui->NextpushButton->setEnabled(false); }
	}
	
}

QImage cvMat2QImage(const Mat & mat)
{
	// 8-bits unsigned, NO. OF CHANNELS = 1  
	if (mat.type() == CV_8UC1)
	{
		QImage image(mat.cols, mat.rows, QImage::Format_Indexed8);
		// Set the color table (used to translate colour indexes to qRgb values)  
		image.setColorCount(256);
		for (int i = 0; i < 256; i++)
		{
			image.setColor(i, qRgb(i, i, i));
		}
		// Copy input Mat  
		uchar *pSrc = mat.data;
		for (int row = 0; row < mat.rows; row++)
		{
			uchar *pDest = image.scanLine(row);
			memcpy(pDest, pSrc, mat.cols);
			pSrc += mat.step;
		}
		return image;
	}
	// 8-bits unsigned, NO. OF CHANNELS = 3  
	else if (mat.type() == CV_8UC3)
	{
		// Copy input Mat  
		const uchar *pSrc = (const uchar*)mat.data;
		// Create QImage with same dimensions as input Mat  
		QImage image(pSrc, mat.cols, mat.rows, mat.step, QImage::Format_RGB888);
		return image.rgbSwapped();
	}
	else if (mat.type() == CV_8UC4)
	{
		qDebug() << "CV_8UC4";
		// Copy input Mat  
		const uchar *pSrc = (const uchar*)mat.data;
		// Create QImage with same dimensions as input Mat  
		QImage image(pSrc, mat.cols, mat.rows, mat.step, QImage::Format_ARGB32);
		return image.copy();
	}
	else
	{
		qDebug() << "ERROR: Mat could not be converted to QImage.";
		return QImage();
	}
}
