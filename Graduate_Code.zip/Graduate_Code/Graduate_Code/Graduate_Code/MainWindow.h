#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_MainWindow.h"

class MainWindow : public QMainWindow
{
	Q_OBJECT

public:
	MainWindow(QWidget *parent = Q_NULLPTR);
	void SetPushButtonClose();
	~MainWindow();

private:
	Ui::MainWindow *ui;

signals:
	void Signal_ToTrain();//ת��ѵ���Ľ���
	void Signal_ToTestPicture();//ת�����ͼƬ�Ľ���
	void Signal_ToTestVideo();//ת����Ƶ���Ľ���

private slots:
	void ConvertToTrain();
	void ConvertToTestPicture();
	void ConvertToTestVideo();
	void RecieveFromTrain();
};
