#include "MainWindow.h"
#include "TrainProcess.h"
#include "ShowTestedPicture.h"
#include "VideoTest.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	MainWindow w;
	TrainProcess p;
	TestedPicture t;
	VideoTest v;
	QObject::connect(&w, SIGNAL(Signal_ToTrain()), &p, SLOT(RecieveToTrain()));
	QObject::connect(&w, SIGNAL(Signal_ToTestPicture()), &t, SLOT(ConvertToTestPicture()));
	QObject::connect(&w, SIGNAL(Signal_ToTestVideo()), &v, SLOT(RecieveToBoard()));
	QObject::connect(&p, SIGNAL(Signal_ToMainWindow()), &w, SLOT(RecieveFromTrain()));
	QObject::connect(&t, SIGNAL(Signal_ToMainWindow()), &w, SLOT(RecieveFromTrain()));
	w.show();

	return a.exec();
}
