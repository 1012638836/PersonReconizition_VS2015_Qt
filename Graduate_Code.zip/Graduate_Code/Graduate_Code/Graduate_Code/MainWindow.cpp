#include "MainWindow.h"

MainWindow::MainWindow(QWidget *parent)
	: QMainWindow(parent),ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	connect(ui->TrainpushButton, SIGNAL(clicked()), this, SLOT(ConvertToTrain()));
	connect(ui->PicturepushButton, SIGNAL(clicked()), this, SLOT(ConvertToTestPicture()));
	connect(ui->VideopushButton, SIGNAL(clicked()), this, SLOT(ConvertToTestVideo()));
}
void MainWindow::ConvertToTrain()
{
	emit Signal_ToTrain();
	SetPushButtonClose();
}

void MainWindow::ConvertToTestPicture()
{
	emit Signal_ToTestPicture();
	SetPushButtonClose();
}
void MainWindow::ConvertToTestVideo()
{
	emit Signal_ToTestVideo();
	SetPushButtonClose();
}
void MainWindow::RecieveFromTrain()
{
	ui->TrainpushButton->setEnabled(true);
	ui->PicturepushButton->setEnabled(true);
	ui->VideopushButton->setEnabled(true);
}
void MainWindow::SetPushButtonClose()
{
	ui->PicturepushButton->setEnabled(false);
	ui->TrainpushButton->setEnabled(false);
	ui->VideopushButton->setEnabled(false);
}

MainWindow::~MainWindow()
{
	delete ui;
}
