/********************************************************************************
** Form generated from reading UI file 'TrainProcess.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRAINPROCESS_H
#define UI_TRAINPROCESS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_TrainProcess
{
public:
    QTextBrowser *textBrowser;
    QPushButton *PospushButton;
    QLabel *Poslabel;
    QPushButton *NegpushButton;
    QLabel *Neglabel;
    QPushButton *StartpushButton;
    QProgressBar *progressBar;

    void setupUi(QDialog *TrainProcess)
    {
        if (TrainProcess->objectName().isEmpty())
            TrainProcess->setObjectName(QStringLiteral("TrainProcess"));
        TrainProcess->resize(642, 467);
        textBrowser = new QTextBrowser(TrainProcess);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(350, 20, 256, 331));
        PospushButton = new QPushButton(TrainProcess);
        PospushButton->setObjectName(QStringLiteral("PospushButton"));
        PospushButton->setGeometry(QRect(40, 40, 231, 28));
        Poslabel = new QLabel(TrainProcess);
        Poslabel->setObjectName(QStringLiteral("Poslabel"));
        Poslabel->setGeometry(QRect(40, 80, 231, 31));
        NegpushButton = new QPushButton(TrainProcess);
        NegpushButton->setObjectName(QStringLiteral("NegpushButton"));
        NegpushButton->setGeometry(QRect(40, 130, 231, 28));
        Neglabel = new QLabel(TrainProcess);
        Neglabel->setObjectName(QStringLiteral("Neglabel"));
        Neglabel->setGeometry(QRect(40, 170, 231, 41));
        StartpushButton = new QPushButton(TrainProcess);
        StartpushButton->setObjectName(QStringLiteral("StartpushButton"));
        StartpushButton->setGeometry(QRect(40, 250, 231, 181));
        progressBar = new QProgressBar(TrainProcess);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setGeometry(QRect(357, 390, 251, 23));
        progressBar->setValue(0);

        retranslateUi(TrainProcess);

        QMetaObject::connectSlotsByName(TrainProcess);
    } // setupUi

    void retranslateUi(QDialog *TrainProcess)
    {
        TrainProcess->setWindowTitle(QApplication::translate("TrainProcess", "Dialog", Q_NULLPTR));
        PospushButton->setText(QApplication::translate("TrainProcess", "\346\211\223\345\274\200\350\256\255\347\273\203\345\233\276\347\211\207\357\274\210\346\255\243\344\276\213\357\274\211", Q_NULLPTR));
        Poslabel->setText(QString());
        NegpushButton->setText(QApplication::translate("TrainProcess", "\346\211\223\345\274\200\350\256\255\347\273\203\346\240\267\346\234\254\357\274\210\350\264\237\344\276\213\357\274\211", Q_NULLPTR));
        Neglabel->setText(QString());
        StartpushButton->setText(QApplication::translate("TrainProcess", "\345\274\200\345\247\213\350\256\255\347\273\203", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TrainProcess: public Ui_TrainProcess {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRAINPROCESS_H
