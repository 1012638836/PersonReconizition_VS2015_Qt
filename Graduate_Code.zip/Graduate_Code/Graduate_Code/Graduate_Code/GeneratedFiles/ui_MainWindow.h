/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *TrainpushButton;
    QPushButton *PicturepushButton;
    QPushButton *VideopushButton;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(603, 410);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        TrainpushButton = new QPushButton(centralWidget);
        TrainpushButton->setObjectName(QStringLiteral("TrainpushButton"));
        TrainpushButton->setGeometry(QRect(190, 20, 181, 71));
        PicturepushButton = new QPushButton(centralWidget);
        PicturepushButton->setObjectName(QStringLiteral("PicturepushButton"));
        PicturepushButton->setGeometry(QRect(190, 110, 181, 61));
        VideopushButton = new QPushButton(centralWidget);
        VideopushButton->setObjectName(QStringLiteral("VideopushButton"));
        VideopushButton->setGeometry(QRect(192, 190, 181, 71));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        TrainpushButton->setText(QApplication::translate("MainWindow", "\350\256\255\347\273\203\346\250\241\345\236\213", Q_NULLPTR));
        PicturepushButton->setText(QApplication::translate("MainWindow", "\345\233\276\347\211\207\346\243\200\346\265\213", Q_NULLPTR));
        VideopushButton->setText(QApplication::translate("MainWindow", "\350\247\206\351\242\221\346\243\200\346\265\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
