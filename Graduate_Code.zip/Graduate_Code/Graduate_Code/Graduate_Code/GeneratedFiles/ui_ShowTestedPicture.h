/********************************************************************************
** Form generated from reading UI file 'ShowTestedPicture.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWTESTEDPICTURE_H
#define UI_SHOWTESTEDPICTURE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_TestedPicture
{
public:
    QPushButton *pushButton;
    QLabel *TestedPicturelabel;
    QLabel *PicturePathlabel;
    QPushButton *LastpushButton;
    QPushButton *NextpushButton;
    QLabel *Originallabel;
    QPushButton *StartTestpushButton;
    QPushButton *SVMpushButton;

    void setupUi(QDialog *TestedPicture)
    {
        if (TestedPicture->objectName().isEmpty())
            TestedPicture->setObjectName(QStringLiteral("TestedPicture"));
        TestedPicture->resize(1162, 532);
        pushButton = new QPushButton(TestedPicture);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 60, 171, 51));
        TestedPicturelabel = new QLabel(TestedPicture);
        TestedPicturelabel->setObjectName(QStringLiteral("TestedPicturelabel"));
        TestedPicturelabel->setGeometry(QRect(580, 20, 511, 471));
        PicturePathlabel = new QLabel(TestedPicture);
        PicturePathlabel->setObjectName(QStringLiteral("PicturePathlabel"));
        PicturePathlabel->setGeometry(QRect(10, 120, 171, 16));
        LastpushButton = new QPushButton(TestedPicture);
        LastpushButton->setObjectName(QStringLiteral("LastpushButton"));
        LastpushButton->setGeometry(QRect(40, 457, 91, 51));
        NextpushButton = new QPushButton(TestedPicture);
        NextpushButton->setObjectName(QStringLiteral("NextpushButton"));
        NextpushButton->setGeometry(QRect(210, 457, 91, 51));
        Originallabel = new QLabel(TestedPicture);
        Originallabel->setObjectName(QStringLiteral("Originallabel"));
        Originallabel->setGeometry(QRect(40, 200, 271, 211));
        StartTestpushButton = new QPushButton(TestedPicture);
        StartTestpushButton->setObjectName(QStringLiteral("StartTestpushButton"));
        StartTestpushButton->setGeometry(QRect(380, 230, 93, 28));
        SVMpushButton = new QPushButton(TestedPicture);
        SVMpushButton->setObjectName(QStringLiteral("SVMpushButton"));
        SVMpushButton->setGeometry(QRect(200, 60, 141, 51));

        retranslateUi(TestedPicture);

        QMetaObject::connectSlotsByName(TestedPicture);
    } // setupUi

    void retranslateUi(QDialog *TestedPicture)
    {
        TestedPicture->setWindowTitle(QApplication::translate("TestedPicture", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("TestedPicture", "\346\211\223\345\274\200\345\276\205\346\243\200\346\265\213\347\232\204\346\226\207\344\273\266", Q_NULLPTR));
        TestedPicturelabel->setText(QString());
        PicturePathlabel->setText(QString());
        LastpushButton->setText(QApplication::translate("TestedPicture", "\344\270\212\344\270\200\345\274\240", Q_NULLPTR));
        NextpushButton->setText(QApplication::translate("TestedPicture", "\344\270\213\344\270\200\345\274\240", Q_NULLPTR));
        Originallabel->setText(QString());
        StartTestpushButton->setText(QApplication::translate("TestedPicture", "\345\274\200\345\247\213\346\243\200\346\265\213", Q_NULLPTR));
        SVMpushButton->setText(QApplication::translate("TestedPicture", "\346\211\223\345\274\200SVM\346\250\241\345\236\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TestedPicture: public Ui_TestedPicture {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWTESTEDPICTURE_H
