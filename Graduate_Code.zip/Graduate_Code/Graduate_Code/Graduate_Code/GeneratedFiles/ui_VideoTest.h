/********************************************************************************
** Form generated from reading UI file 'VideoTest.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIDEOTEST_H
#define UI_VIDEOTEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_VideoTest
{
public:
    QPushButton *OpenVideopushButton;
    QLabel *Statuslabel;
    QLabel *OriginalVideolabel;
    QPushButton *StartTestpushButton;
    QLabel *TestedVideolabel;
    QPushButton *OpenSVMpushButton;
    QLabel *SVMPathlabel;
    QPushButton *StoppushButton;

    void setupUi(QDialog *VideoTest)
    {
        if (VideoTest->objectName().isEmpty())
            VideoTest->setObjectName(QStringLiteral("VideoTest"));
        VideoTest->resize(942, 618);
        OpenVideopushButton = new QPushButton(VideoTest);
        OpenVideopushButton->setObjectName(QStringLiteral("OpenVideopushButton"));
        OpenVideopushButton->setGeometry(QRect(60, 80, 121, 41));
        Statuslabel = new QLabel(VideoTest);
        Statuslabel->setObjectName(QStringLiteral("Statuslabel"));
        Statuslabel->setGeometry(QRect(200, 90, 161, 16));
        OriginalVideolabel = new QLabel(VideoTest);
        OriginalVideolabel->setObjectName(QStringLiteral("OriginalVideolabel"));
        OriginalVideolabel->setGeometry(QRect(20, 220, 241, 211));
        StartTestpushButton = new QPushButton(VideoTest);
        StartTestpushButton->setObjectName(QStringLiteral("StartTestpushButton"));
        StartTestpushButton->setGeometry(QRect(290, 220, 121, 111));
        TestedVideolabel = new QLabel(VideoTest);
        TestedVideolabel->setObjectName(QStringLiteral("TestedVideolabel"));
        TestedVideolabel->setGeometry(QRect(470, 100, 431, 461));
        OpenSVMpushButton = new QPushButton(VideoTest);
        OpenSVMpushButton->setObjectName(QStringLiteral("OpenSVMpushButton"));
        OpenSVMpushButton->setGeometry(QRect(60, 140, 121, 41));
        SVMPathlabel = new QLabel(VideoTest);
        SVMPathlabel->setObjectName(QStringLiteral("SVMPathlabel"));
        SVMPathlabel->setGeometry(QRect(200, 150, 161, 16));
        StoppushButton = new QPushButton(VideoTest);
        StoppushButton->setObjectName(QStringLiteral("StoppushButton"));
        StoppushButton->setGeometry(QRect(290, 340, 121, 101));

        retranslateUi(VideoTest);

        QMetaObject::connectSlotsByName(VideoTest);
    } // setupUi

    void retranslateUi(QDialog *VideoTest)
    {
        VideoTest->setWindowTitle(QApplication::translate("VideoTest", "Dialog", Q_NULLPTR));
        OpenVideopushButton->setText(QApplication::translate("VideoTest", "\346\211\223\345\274\200\350\247\206\351\242\221\346\226\207\344\273\266", Q_NULLPTR));
        Statuslabel->setText(QString());
        OriginalVideolabel->setText(QString());
        StartTestpushButton->setText(QApplication::translate("VideoTest", "\345\274\200\345\247\213\346\243\200\346\265\213", Q_NULLPTR));
        TestedVideolabel->setText(QString());
        OpenSVMpushButton->setText(QApplication::translate("VideoTest", "\346\211\223\345\274\200SVM\346\226\207\344\273\266", Q_NULLPTR));
        SVMPathlabel->setText(QString());
        StoppushButton->setText(QApplication::translate("VideoTest", "\345\201\234\346\255\242\346\243\200\346\265\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class VideoTest: public Ui_VideoTest {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIDEOTEST_H
