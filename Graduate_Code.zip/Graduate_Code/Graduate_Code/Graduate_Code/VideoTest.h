#pragma once
#include "ui_VideoTest.h"
#include <QDialog>
#include <QTimer>
#include <QFileDialog>
#include <QMessageBox>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\objdetect\objdetect.hpp>
#include <opencv2\ml.hpp>
#include <opencv2\core\core.hpp>
using namespace cv;
using namespace cv::ml;
class VideoTest :public QDialog
{
	Q_OBJECT
public:
	VideoTest(QWidget *parent = Q_NULLPTR);
	~VideoTest();
private:
	Ui::VideoTest *ui;
	QTimer theTimer;
	VideoCapture cap;
	Mat srcImage;
	QString VideoFileName;
	QString SVMPath;
	HOGDescriptor hog;
private slots:
	void ClickedTestVideo();
	void RecieveToBoard();
	void onTimeout();
	void StartTest();
	void OpenSVMFile();
//	void updateImage();
};
